<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Default Settings</label>
    <protected>false</protected>
    <values>
        <field>Error_Email_Recipient__c</field>
        <value xsi:type="xsd:string">samduncan18@gmail.com</value>
    </values>
    <values>
        <field>Months_Before__c</field>
        <value xsi:type="xsd:double">3.0</value>
    </values>
    <values>
        <field>Org_Wide_Address_Name__c</field>
        <value xsi:type="xsd:string">Grainger Renewals</value>
    </values>
</CustomMetadata>
